# Jianzheng 1.1.0

Some fast-to-use APIs those provide ML solutions.

<!-- ## Donate

If you like this package and want to help me develop, donate please? You don't need to donate too much, just one or two dollar is enough， どうもありがとうございました! -->

## Links

- Documentation: [./docs](./docs/index.md)
- Changelog: [./CHANGELOG.md](./CHANGELOG.md)
- PyPI Releases: [https://pypi.org/manage/project/jianzheng/releases/](https://pypi.org/manage/project/jianzheng/releases/)
- Source Code: [https://github.com/JianzhengLuo/jianzheng](https://github.com/JianzhengLuo/jianzheng)
- Issue Tracker: [https://github.com/JianzhengLuo/jianzheng/issues](https://github.com/JianzhengLuo/jianzheng/issues)
- Website: [https://jianzhengluo.github.io/jianzheng/](https://jianzhengluo.github.io/jianzheng/)

## License

This project follows [MediaPipe](https://github.com/google/mediapipe) to use [Apache 2.0 License](./LICENSE). 

PS: I don't know know too much about license, so **IF I DID ANYTHING WRONG**, please **EMAIL ME AT *jianzheng.luo.china@gmail.com***. I will rectify it as soon as possible.
