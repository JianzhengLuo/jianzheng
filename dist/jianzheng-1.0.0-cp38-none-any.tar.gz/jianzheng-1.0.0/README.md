# Jianzheng

## About this package

Hi, I am Jianzheng Luo. A middle school student from China. I have the idea to write this package in late 2021 ---- when I know google developed MediaPipe. It can run on my computer quite fast by only using CPU. But there are few docs of it. I want to encapsulate it, like Django encapsulate Flask. I think I will enrich it with some fast-to-use APIs and some graphical tools. Get ready for it!